﻿using AdventOfCode.Lib;
using AdventOfCode.Lib.IO;
using System.Threading.Tasks;

namespace $rootnamespace$
{
	[Challenge()]
	public class $safeitemrootname$
	{
		private readonly IInputReader inputReader;

		public $safeitemrootname$(IInputReader inputReader)
		{
			this.inputReader = inputReader;
		}

		[Setup]
		public async Task SetupAsync()
		{

		}

		[Part1]
		public string Part1()
		{
			return null;
		}

		[Part2]
		public string Part2()
		{
			return null;
		}
	}
}
