﻿using AdventOfCode.Lib;
using AdventOfCode.Lib.IO;
using System.Threading.Tasks;

namespace $rootnamespace$
{
	[Challenge()]
	public class $safeitemrootname$
	{
		private readonly IInputReader _inputReader;

		public $safeitemrootname$(IInputReader inputReader)
		{
			_inputReader = inputReader;
		}

		[Part1]
		public async Task<string> Part1Async()
		{
			return null;
		}

		[Part2]
		public async Task<string> Part2Async()
		{
			return null;
		}
	}
}
